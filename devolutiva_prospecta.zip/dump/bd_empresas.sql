-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 03-Jul-2017 às 08:52
-- Versão do servidor: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bd_empresas`
--
CREATE DATABASE IF NOT EXISTS `bd_empresas` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bd_empresas`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `empresas`
--

CREATE TABLE `empresas` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'Identiicador único de cadastro de cada empresa.',
  `razao_social` varchar(60) NOT NULL COMMENT 'Razão social da empresa. ',
  `nome_fantasia` varchar(60) NOT NULL COMMENT 'Nome fantasia da empresa.',
  `ddd` smallint(3) UNSIGNED NOT NULL COMMENT 'DDD do número de  telefone da empresa.',
  `telefone` bigint(10) UNSIGNED NOT NULL COMMENT 'Telefone da empresa.',
  `cnpj` varchar(18) NOT NULL COMMENT 'CNPJ da empresa.',
  `site` varchar(60) DEFAULT NULL COMMENT 'Site da empresa (opcional).'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabela que guarda as informações das empresas cadastradas.';

--
-- Extraindo dados da tabela `empresas`
--

INSERT INTO `empresas` (`id`, `razao_social`, `nome_fantasia`, `ddd`, `telefone`, `cnpj`, `site`) VALUES
(1, 'Google Comércio', 'Google C.', 47, 986402039, '08.942.765/0001-52', 'https://www.google.com.br'),
(2, 'Facebook Indústrias', 'Facebook', 11, 978784654, '39.470.162/0001-29', 'https://www.facebook.com/'),
(3, 'Stark Indústrias Ltda.', 'Stark', 22, 234260677, '50.276.984/0001-06', ''),
(4, 'Cork Comércio', 'Cork ', 55, 344355677, '52.038.761/0001-36', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `empresas`
--
ALTER TABLE `empresas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `empresas`
--
ALTER TABLE `empresas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identiicador único de cadastro de cada empresa.', AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
