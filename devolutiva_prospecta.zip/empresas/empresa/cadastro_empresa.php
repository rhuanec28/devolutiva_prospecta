<?php
	//Incluindo a conexão com o banco e as funções para fazer as validações.
	include "../banco/conexao_banco.php";
	include "../funcoes/funcoes_validacao.php";

	$p_razao = $_POST['txtrazao'];
	$p_nome = $_POST['txtnome'];
	$p_ddd = $_POST['txtddd'];
	$p_telefone = $_POST['txttelefone'];
	$p_cnpj = $_POST['txtcnpj'];
	$p_site = $_POST['txtsite'];
	$classe = "Erro";

	$sql_sel_empresas = "SELECT * FROM empresas WHERE cnpj='".$p_cnpj."'";
	$sql_sel_empresas_preparado = $conexaobd->prepare($sql_sel_empresas);
	$sql_sel_empresas_preparado->execute();

	//Verificando campos preenchidos
	if($p_razao==""){
		$msg = "O campo Razão Social é obrigatório.";
	}else if($p_nome==""){
		$msg = "O campo Nome Fantasia é obrigatório.";
	}else if(!validacao_cnpj($p_cnpj)){
		$msg = "Digite um CNPJ válido. (Digite no formato XX.XXX.XXX/XXXX-XX)";
	}else if(!validacao_numeros($p_ddd)){
		$msg = "Preencha corretamente o campo DDD.";
	}else if(!validacao_telefone($p_telefone)){
		$msg = "Preencha corretamente o campo Telefone.";
	}else if((!filter_var($p_site, FILTER_VALIDATE_URL))&&($p_site!="")){
		$msg = "Preencha corretamente o campo Site.";
	}else if($sql_sel_empresas_preparado->rowCount()!=0){
		$msg = "CNPJ já cadastrado.";
	}else{
		//Caso estejam validados e corretos, os campos são inseridos no banco.

		  $sql_ins_empresas = "INSERT INTO empresas (razao_social, nome_fantasia, ddd, telefone, cnpj, site) VALUES ('".$p_razao."', '".$p_nome."', '".$p_ddd."', '".$p_telefone."', '".$p_cnpj."', '".$p_site."')";
		  $sql_ins_empresas_preparado = $conexaobd->prepare($sql_ins_empresas);
		  $sql_ins_empresas_resultado = $sql_ins_empresas_preparado->execute();
		  if($sql_ins_empresas_resultado){
				$msg = "Cadastro de empresa efetuado com sucesso!";
				$classe = "Sucesso";
		  }else{
				$msg = "Erro ao efetuar o cadastro de empresa.";
	  	}
	}
?>
<html lang="pt-br">
	<head>
		<title>Bem vindo!</title>
		<meta name="author" content="Rhuan Eládio de Carvalho">
		<meta name="description" content="Software para cadastro de empresas.">
		<meta charset="utf8">
		<link href="../estilo/estilo.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header>
		<nav>
			<ul>
				<a href="../index.php"><li>Início</li></a>
				<a href="formCadastro_empresa.php"><li>Cadastrar empresa</li></a>
			</ul>
		</nav>
	</header>
	<div id="conteudo">
		<h1 class="titulo_paginas">Cadastro de Empresa</h1>
		<div class="conteudo_pagina">
			<section class="<?php echo $classe; ?>">
			  <div>
				<h1><?php echo $classe ?></h1> <!-- mostra se é erro ou sucesso-->
				<p class=p_aviso><?php echo $msg ?></p> <!-- mostra a mensagem de erro ou sucesso-->
				<a href="formCadastro_empresa.php">Voltar</a>
			  </div>
			</section>
		</div>
	</div>
  </body>
</html>
