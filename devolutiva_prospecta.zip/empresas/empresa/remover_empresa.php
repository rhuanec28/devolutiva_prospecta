<?php
  include "../banco/conexao_banco.php";

  $g_id = $_GET['id'];
  $classe = "Erro";
  if($g_id==""){
    $msg = "Id inexistente.";
  }else{
    $sql_del_empresas = "DELETE FROM empresas WHERE id='".$g_id."'";
    $sql_del_empresas_preparado = $conexaobd->prepare($sql_del_empresas);
    $sql_del_empresas_resultado = $sql_del_empresas_preparado->execute();

    if($sql_del_empresas_resultado){
      $msg = "Empresa removida com sucesso.";
      $classe = "Sucesso";
    }else{
      $msg = "Erro ao remover empresa.";
    }
  }
  ?>
  <html lang="pt-br">
  	<head>
  		<title>Bem vindo!</title>
  		<meta name="author" content="Rhuan Eládio de Carvalho">
  		<meta name="description" content="Software para cadastro de empresas">\
  		<meta charset="utf8">
  		<link href="../estilo/estilo.css" rel="stylesheet" type="text/css">
  	</head>
  	<body>
  	<header>
  		<nav>
  			<ul>
  				<a href="../index.php"><li>Início</li></a>
  				<a href="formCadastro_empresa.php"><li>Cadastrar empresa</li></a>
  			</ul>
  		</nav>
  	</header>
  	<div id="conteudo">
  		<h1 class="titulo_paginas">Cadastro de Empresa</h1>
  		<div class="conteudo_pagina">
  			<section class="<?php echo $classe; ?>">
  			  <div>
  				<h1><?php echo $classe ?></h1> <!-- mostra se é erro ou sucesso-->
  				<p class=p_aviso><?php echo $msg ?></p> <!-- mostra a mensagem de erro ou sucesso-->
  				<a href="formCadastro_empresa.php">Voltar</a>
  			  </div>
  			</section>
  		</div>
  	</div>
    </body>
  </html>
