<?php
	include "../banco/conexao_banco.php";
?>
<html lang="pt-br">
	<head>
		<title>Cadastro de empresa</title>
		<meta name="author" content="Rhuan Eládio de Carvalho">
		<meta name="description" content="Software para cadastro de empresas.">
		<meta charset="utf8">
		<link href="../estilo/estilo.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header> <!--Inicio cabeçalho-->
		<nav> <!--Inicio menu-->
			<ul>
				<a href="../index.php"><li>Início</li></a>
				<a href="#"><li>Cadastrar empresa</li></a>
			</ul>
		</nav> <!--Fim menu-->
	</header> <!--Fim cabeçalho-->
	<div id="conteudo">
		<h1 class="titulo_paginas">Cadastro de Empresa</h1>
		<div class="conteudo_pagina">
			<section>
				<fieldset>
					<form name="formempresa" method="POST" action="cadastro_empresa.php" class="form">
						<table>
							<tr>
								<td>*Razão Social:</td>
								<td><input type="text" name="txtrazao" maxlength="60" ></td>
							</tr>
							<tr>
								<td>*Nome Fantasia:</td>
								<td><input type="text" name="txtnome" maxlength="60" ></td>
							</tr>
							<tr>
								<td>*CNPJ:</td>
								<td><input type="text" name="txtcnpj" maxlength="18" placeholder="XX.XXX.XXX/XXXX-XX"></td>
							</tr>
							<tr>
								<td>*DDD:</td>
								<td><input type="text" name="txtddd" maxlength="3" ></td>
							</tr>
							<tr>
								<td>*Telefone (sem hífen):</td>
								<td><input type="text" name="txttelefone" maxlength="10" placeholder="999808489" ></td>
							</tr>
							<tr>
								<td>Site:</td>
								<td><input type="text" name="txtsite" maxlength="60" placeholder="https://www.google.com.br"></td>
							</tr>
							<tr>
								<td colspan="" align="center">
									<button name="btnreset" type="reset" class="reset" style="width:  70%;">Limpar</button>
								</td>
								<td colspan="" align="center">
									<button name="btnsubmit" type="submit" class="submit">Cadastrar</button>
								</td>
							</tr>
						</table>
					</form>
				</fieldset>
			</section>
			<h3 class="subtitulos_paginas">Registros</h3>
				<table class="mostra_cadastro">
					<thead>
						<tr>
							<th width="10%">ID</th>
							<th width="20%">Razão Social</th>
							<th width="20%">Nome Fantasia</th>
							<th width="20%">Telefone</th>
							<th width="20%">CNPJ</th>
							<th width="20%">Site</th>
							<th width="20%">Remover</th>
						</tr>
					</thead>
					<tbody>
						<?php

						  //Pesquisa da tabela empresas
						  $sql_sel_empresas = "SELECT * FROM empresas ORDER BY id ASC";
						  $sql_sel_empresas_preparado = $conexaobd->prepare($sql_sel_empresas);
						  $sql_sel_empresas_preparado->execute();
						  //Fim pesquisa empresas
							if($sql_sel_empresas_preparado->rowCount()>0){
							  while($sql_sel_empresas_dados = $sql_sel_empresas_preparado->fetch()){

						  ?>
								<tr>
									<td><?php echo $sql_sel_empresas_dados['id']; ?></td>
									<td><?php echo $sql_sel_empresas_dados['razao_social']; ?></td>
									<td><?php echo $sql_sel_empresas_dados['nome_fantasia']; ?></td>
									<td>(<?php echo $sql_sel_empresas_dados['ddd']; ?>) <?php echo $sql_sel_empresas_dados['telefone']; ?></td>
									<td><?php echo $sql_sel_empresas_dados['cnpj']; ?></td>
									<td>
									<?php
									if($sql_sel_empresas_dados['site']!=""){
										echo $sql_sel_empresas_dados['site'];
									}else{
										echo "Não cadastrado.";
									}  ?>
									</td>
									<td>
										<a href="remover_empresa.php?id=<?php echo $sql_sel_empresas_dados['id']; ?>"s title="Remover Registro"><img width="40px";  src="../imagens/remover.png"></a>
									</td>
								</tr>
							<?php
								}
							  }else{
							?>
								<tr>
								  <td align="center" colspan="7">Não há empresas cadastradas.</td>
								</tr>
							<?php
							  }
							?>
					</tbody>
				</table>
		</div>
	</div>
  </body>
</html>
