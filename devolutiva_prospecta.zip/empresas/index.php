<html lang="pt-br">
	<head>
		<title>Bem vindo!</title>
		<meta name="author" content="Rhuan Eládio de Carvalho">
		<meta name="description" content="Software para cadastro de empresas.">
		<meta charset="utf8">
		<link href="estilo/estilo.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<header> <!--Inicio cabeçalho-->
		<nav> <!--Inicio menu-->
			<ul>
				<a href="index.php"><li>Início</li></a>
				<a href="empresa/formCadastro_empresa.php"><li>Cadastrar empresa</li></a>
			</ul>
		</nav> <!--Fim menu-->
	</header> <!--Fim cabeçalho-->
	<div id="conteudo">
		<h1 class="titulo_paginas">Bem vindo</h1>
		<div class="intro">
			<p class="texto"><b>Desenvolvedor:</b> Rhuan Eládio de Carvalho </p>
		</div>
	</div>
  </body>
</html>
