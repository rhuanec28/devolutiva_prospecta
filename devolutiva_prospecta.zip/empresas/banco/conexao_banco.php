<?php
  //Arquivo para conexão com o banco de dados.
  try {
      $conexaobd = new PDO("mysql:host=localhost;dbname=bd_empresas;charset=utf8", "root", ""); 
    } catch (PDOException $e) {
      die ("Erro ao se conectar com o banco de dados: ".$e->getMessage());
    }
?>
