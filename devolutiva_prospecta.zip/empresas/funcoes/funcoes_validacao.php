<!-- PAGINA PARA EXPRESSOES REGULARES DO SITE. -->
<?php

 // PARA VALIDAR TELEFONE
 function validacao_telefone($dados){
   $expressao_telefone = "/^([0-9]{1,9})$/";
   $preg = preg_match($expressao_telefone, $dados);
   if($preg==""){
     return false;
   }else{
     return true;
   }
 }

 function validacao_numeros($dados){
   $expressao_numeros = "/^([0-9]{1,3})$/";
   $preg = preg_match($expressao_numeros, $dados);

   if($preg==""){
     return false;
   }else{
     return true;
   }
 }

 function validacao_cnpj ($dados) {
 	// Deixa o CNPJ com apenas números
 	$dados = preg_replace( '/[^0-9]/', '', $dados );

 	// Garante que o CNPJ é uma string
 	$dados = (string)$dados;

 	// O valor original
 	$dados_original = $dados;

 	// Captura os primeiros 12 números do CNPJ
 	$primeiros_numeros_cnpj = substr( $dados, 0, 12 );

 	/**
 	 * Multiplicação do CNPJ
 	 */
 	if (!function_exists('multiplica_cnpj')) {
 		function multiplica_cnpj( $dados, $posicao = 5 ) {
 			// Variável para o cálculo
 			$calculo = 0;

 			// Laço para percorrer os item do cnpj
 			for ( $i = 0; $i < strlen( $dados ); $i++ ) {
 				// Cálculo mais posição do CNPJ * a posição
 				$calculo = $calculo + ( $dados[$i] * $posicao );

 				// Decrementa a posição a cada volta do laço
 				$posicao--;

 				// Se a posição for menor que 2, ela se torna 9
 				if ( $posicao < 2 ) {
 					$posicao = 9;
 				}
 			}
 			// Retorna o cálculo
 			return $calculo;
 		}
 	}

 	// Faz o primeiro cálculo
 	$primeiro_calculo = multiplica_cnpj( $primeiros_numeros_cnpj );

 	// Se o resto da divisão entre o primeiro cálculo e 11 for menor que 2, o primeiro
 	// Dígito é zero (0), caso contrário é 11 - o resto da divisão entre o cálculo e 11
 	$primeiro_digito = ( $primeiro_calculo % 11 ) < 2 ? 0 :  11 - ( $primeiro_calculo % 11 );

 	// Concatena o primeiro dígito nos 12 primeiros números do CNPJ
 	// Agora temos 13 números aqui
 	$primeiros_numeros_cnpj .= $primeiro_digito;

 	// O segundo cálculo é a mesma coisa do primeiro, porém, começa na posição 6
 	$segundo_calculo = multiplica_cnpj( $primeiros_numeros_cnpj, 6 );
 	$segundo_digito = ( $segundo_calculo % 11 ) < 2 ? 0 :  11 - ( $segundo_calculo % 11 );

 	// Concatena o segundo dígito ao CNPJ
 	$dados = $primeiros_numeros_cnpj . $segundo_digito;

 	// Verifica se o CNPJ gerado é idêntico ao enviado
 	if ( $dados === $dados_original ) {
 		return true;
 	}
 }




?>
